          // Created By Abir
          

alert("\n       Tap anywhere to enable music\n");
  
window.addEventListener("mouseover",play);
window.addEventListener("click",play);
function play(){ document.getElementById("audio").play();
}
  